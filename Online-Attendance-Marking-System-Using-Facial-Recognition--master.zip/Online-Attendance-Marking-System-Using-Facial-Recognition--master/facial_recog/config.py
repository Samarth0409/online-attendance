import os

KNOWN_IMG_DIR = os.path.join(os.getcwd(), 'facial_recog', 'img', 'known_users')
TO_BE_PROCESSED_IMG_DIR = os.path.join(os.getcwd(), 'facial_recog', 'img', 'unknown_users')
ENCODINGS_FILE = os.path.join(os.getcwd(), 'facial_recog', 'enc', 'dataset_faces.dat')
